package com.example.myapplication;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Log;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate Called");

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        TextView myTextView = findViewById(R.id.my_text_view);
        String greeting = getResources().getString(R.string.hello_world);
        myTextView.setText(getString(R.string.nouveau_texte));

        Toast.makeText(this, getString(R.string.activity_created), Toast.LENGTH_SHORT).show();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (savedInstanceState != null) {
            String savedText = savedInstanceState.getString("text_key");
            if (savedText != null) {
                myTextView.setText(savedText);
            }
        }

        Button myButton = findViewById(R.id.button_open_second_activity);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 在这里处理按钮点击事件
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("lifecycle", "onStart Called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "onResume Called");
        Toast.makeText(this, getString(R.string.activity_on_resume), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause Called");
        Toast.makeText(this, getString(R.string.activity_on_pause), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop Called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart Called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy Called");
    }

    public void openSecondActivity(View view) {
        Log.i(TAG, "Click : openSecondActivity");
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        startActivity(intent);
    }

    public void changeText(View view) {
        TextView textView = findViewById(R.id.text_view);
        if (textView != null) {
            textView.setText("Text Changed!");
        }
        Log.i(TAG, "changeText Called");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_item) {
            // Trafficker un Toast internationalisé
            if (Locale.getDefault().getLanguage().equals("fr")) {
                Toast.makeText(this, "Item cliqué", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item clicked", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        TextView myTextView = findViewById(R.id.my_text_view);
        outState.putString("text_key", myTextView.getText().toString());
    }

}